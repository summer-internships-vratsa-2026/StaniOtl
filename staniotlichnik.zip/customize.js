const questionInput = document.getElementById("questionInput");
const answerA = document.getElementById("answerA");
const answerB = document.getElementById("answerB");
const answerC = document.getElementById("answerC");
const answerD = document.getElementById("answerD");
const correctAnswer = document.getElementById("correctAnswer");
const teacherHint = document.getElementById("teacherHint");
const explanationInput = document.getElementById("explanationInput");

const addQuestionBtn = document.getElementById("addQuestionBtn");
const clearQuestionsBtn = document.getElementById("clearQuestionsBtn");
const defaultQuestionsBtn = document.getElementById("defaultQuestionsBtn");
const messageBox = document.getElementById("messageBox");
const questionsList = document.getElementById("questionsList");
const helpTimerInput = document.getElementById("helpTimerInput");
const saveTimerBtn = document.getElementById("saveTimerBtn");

const HELP_TIMER_KEY = "helpTimerSeconds";
const groupNameInput = document.getElementById("groupNameInput");
const saveGroupBtn = document.getElementById("saveGroupBtn");
const groupsList = document.getElementById("groupsList");

const QUESTION_GROUPS_KEY = "questionGroups";
const ACTIVE_GROUP_KEY = "activeQuestionGroupId";
const DEFAULT_QUESTIONS_MODE_KEY = "useDefaultQuestions";
const questionCounter = document.getElementById("questionCounter");

addQuestionBtn.addEventListener("click", addQuestion);
clearQuestionsBtn.addEventListener("click", clearQuestions);
saveTimerBtn.addEventListener("click", saveHelpTimer);
defaultQuestionsBtn.addEventListener("click", useDefaultQuestions);
saveGroupBtn.addEventListener("click", saveCurrentQuestionsAsGroup);

function getSavedQuestions() {
    const saved = localStorage.getItem("customQuestions");

    if (!saved) {
        return [];
    }

    try {
        return JSON.parse(saved);
    } catch (error) {
        return [];
    }
}

function saveQuestions(questions) {
    localStorage.setItem("customQuestions", JSON.stringify(questions));
}

function addQuestion() {
    const question = questionInput.value.trim();
    const a = answerA.value.trim();
    const b = answerB.value.trim();
    const c = answerC.value.trim();
    const d = answerD.value.trim();
    const hint = teacherHint.value.trim();
    const explanation = explanationInput.value.trim();

    if (!question || !a || !b || !c || !d) {
        messageBox.textContent = "Моля, попълни въпроса и всички четири отговора.";
        return;
    }

    const newQuestion = {
    question: question,
    answers: [a, b, c, d],
    correct: Number(correctAnswer.value),
    teacher: hint || "Няма добавена подсказка от учител.",
    explanation: explanation || "Няма добавено пояснение за този въпрос."
};

    const questions = getSavedQuestions();
    questions.push(newQuestion);
    saveQuestions(questions);

    const totalQuestions = questions.length;

if (totalQuestions < 15) {
    messageBox.textContent = `Въпросът е добавен. Трябват ти още ${15 - totalQuestions} въпроса за пълна игра.`;
} else {
    messageBox.textContent = "Готово! Имаш минимум 15 въпроса и можеш да играеш персонализираната игра.";
}

    questionInput.value = "";
    answerA.value = "";
    answerB.value = "";
    answerC.value = "";
    answerD.value = "";
    teacherHint.value = "";
    explanationInput.value = "";
    correctAnswer.value = "0";

    renderQuestions();
}

function renderQuestions() {
    const questions = getSavedQuestions();

    questionsList.innerHTML = "";

    const count = questions.length;
    const remaining = Math.max(15 - count, 0);

    if (count < 15) {
        questionCounter.textContent = `Добавени въпроси: ${count} / 15. Остават още ${remaining} въпроса.`;
    } else {
        questionCounter.textContent = `Добавени въпроси: ${count}. Готово! Имаш достатъчно въпроси за цяла игра.`;
    }

    if (questions.length === 0) {
        questionsList.innerHTML = "<p>Все още няма добавени персонализирани въпроси.</p>";
        return;
    }

    questions.forEach((q, index) => {
        const div = document.createElement("div");
        div.className = "saved-question";

       div.innerHTML = `
        <strong>${index + 1}. ${q.question}</strong>
        <p>A: ${q.answers[0]}</p>
        <p>B: ${q.answers[1]}</p>
        <p>C: ${q.answers[2]}</p>
        <p>D: ${q.answers[3]}</p>
        <p><strong>Верен отговор:</strong> ${String.fromCharCode(65 + q.correct)}</p>
        <p><strong>Пояснение:</strong> ${q.explanation || "Няма добавено пояснение."}</p>
        <button class="delete-btn" onclick="deleteQuestion(${index})">Изтрий</button>
    `;
        questionsList.appendChild(div);
    });
}

function deleteQuestion(index) {
    const questions = getSavedQuestions();
    questions.splice(index, 1);
    saveQuestions(questions);

    messageBox.textContent = "Въпросът е изтрит.";
    renderQuestions();
}

function clearQuestions() {
    const confirmDelete = confirm("Сигурен ли си, че искаш да изтриеш всички персонализирани въпроси?");

    if (!confirmDelete) {
        return;
    }

    localStorage.removeItem("customQuestions");
    messageBox.textContent = "Всички персонализирани въпроси са изтрити.";
    renderQuestions();
}
function getQuestionGroups() {
    const saved = localStorage.getItem(QUESTION_GROUPS_KEY);

    if (!saved) {
        return [];
    }

    try {
        return JSON.parse(saved);
    } catch (error) {
        return [];
    }
}

function saveQuestionGroups(groups) {
    localStorage.setItem(QUESTION_GROUPS_KEY, JSON.stringify(groups));
}

function saveCurrentQuestionsAsGroup() {
    const questions = getSavedQuestions();
    const groupName = groupNameInput.value.trim();

    if (questions.length < 15) {
        messageBox.textContent = "Трябва да имаш минимум 15 въпроса, за да запазиш готова група.";
        return;
    }

    if (!groupName) {
        messageBox.textContent = "Моля, въведи име на групата.";
        return;
    }

    const groups = getQuestionGroups();

    const newGroup = {
        id: Date.now().toString(),
        name: groupName,
        questions: questions.slice(0, 15),
        createdAt: new Date().toLocaleString("bg-BG")
    };

    groups.push(newGroup);
    saveQuestionGroups(groups);

    localStorage.setItem(ACTIVE_GROUP_KEY, newGroup.id);
    localStorage.setItem(DEFAULT_QUESTIONS_MODE_KEY, "false");

    groupNameInput.value = "";

    messageBox.textContent = `Групата „${newGroup.name}“ е запазена и избрана за игра.`;

    renderQuestionGroups();
}

function renderQuestionGroups() {
    const groups = getQuestionGroups();
    const activeGroupId = localStorage.getItem(ACTIVE_GROUP_KEY);

    groupsList.innerHTML = "";

    if (groups.length === 0) {
        groupsList.innerHTML = "<p>Все още няма запазени групи въпроси.</p>";
        return;
    }

    groups.forEach(group => {
        const div = document.createElement("div");
        div.className = "group-item";

        if (group.id === activeGroupId) {
            div.classList.add("active-group");
        }

        div.innerHTML = `
            <div class="group-title">
                ${group.name} ${group.id === activeGroupId ? "— избрана за игра" : ""}
            </div>

            <div class="group-info">
                ${group.questions.length} въпроса | Създадена: ${group.createdAt}
            </div>

            <div class="group-actions">
                <button class="use-group-btn" onclick="useQuestionGroup('${group.id}')">
                    Избери за игра
                </button>

                <button class="edit-group-btn" onclick="loadGroupForEditing('${group.id}')">
                    Зареди за редакция
                </button>

                <button class="delete-group-btn" onclick="deleteQuestionGroup('${group.id}')">
                    Изтрий
                </button>
            </div>
        `;

        groupsList.appendChild(div);
    });
}

function useQuestionGroup(groupId) {
    localStorage.setItem(DEFAULT_QUESTIONS_MODE_KEY, "false");
    localStorage.setItem(ACTIVE_GROUP_KEY, groupId);

    const groups = getQuestionGroups();
    const selectedGroup = groups.find(group => group.id === groupId);

    if (selectedGroup) {
        messageBox.textContent = `Групата „${selectedGroup.name}“ е избрана за игра.`;
    }

    renderQuestionGroups();
}

function loadGroupForEditing(groupId) {
    const groups = getQuestionGroups();
    const selectedGroup = groups.find(group => group.id === groupId);

    if (!selectedGroup) {
        messageBox.textContent = "Групата не е намерена.";
        return;
    }

    localStorage.setItem("customQuestions", JSON.stringify(selectedGroup.questions));
    localStorage.setItem(ACTIVE_GROUP_KEY, groupId);

    messageBox.textContent = `Групата „${selectedGroup.name}“ е заредена за редакция.`;

    renderQuestions();
    renderQuestionGroups();
}

function deleteQuestionGroup(groupId) {
    const confirmDelete = confirm("Сигурен ли си, че искаш да изтриеш тази група въпроси?");

    if (!confirmDelete) {
        return;
    }

    let groups = getQuestionGroups();
    groups = groups.filter(group => group.id !== groupId);

    saveQuestionGroups(groups);

    const activeGroupId = localStorage.getItem(ACTIVE_GROUP_KEY);

    if (activeGroupId === groupId) {
        localStorage.removeItem(ACTIVE_GROUP_KEY);
    }

    messageBox.textContent = "Групата е изтрита.";

    renderQuestionGroups();
}
function useDefaultQuestions() {
    localStorage.setItem(DEFAULT_QUESTIONS_MODE_KEY, "true");

    // Махаме избраната готова група, но НЕ я изтриваме
    localStorage.removeItem(ACTIVE_GROUP_KEY);

    messageBox.textContent = "Стандартните въпроси са избрани за игра.";

    renderQuestionGroups();
}
function loadHelpTimerSetting() {
    const savedTimer = localStorage.getItem(HELP_TIMER_KEY);

    if (savedTimer) {
        helpTimerInput.value = savedTimer;
    } else {
        helpTimerInput.value = "30";
    }
}

function saveHelpTimer() {
    const seconds = Number(helpTimerInput.value);

    if (seconds < 5 || seconds > 120) {
        messageBox.textContent = "Моля, въведи време между 5 и 120 секунди.";
        return;
    }

    localStorage.setItem(HELP_TIMER_KEY, seconds.toString());

    messageBox.textContent = `Таймерът за помощ е запазен: ${seconds} секунди.`;
}
renderQuestions();
renderQuestionGroups();
loadHelpTimerSetting();
